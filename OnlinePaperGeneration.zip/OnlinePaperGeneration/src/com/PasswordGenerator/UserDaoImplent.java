package com.PasswordGenerator;

import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.DBConfiguration.DBConnection;

//import com.mysql.jdbc.PreparedStatement;
public class UserDaoImplent implements UserDao {
	boolean b1;
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public UserDaoImplent() {
		try {
			con = DBConnection.getMySQLConnection();
			System.out.println(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int addUser(User user) {
		System.out.println("hello");
		 
		try {
			String s2 = "select * from users where email=?";
			ps = con.prepareStatement(s2);
			ps.setString(1, user.getEmailId());
			rs = ps.executeQuery();
			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String emailId = rs.getString(3);
				String userName = rs.getString(4);
				String password = rs.getString(5);
				String autoPassword = rs.getString(6);
				String contactNumber = rs.getString(7);
				System.out.println(emailId);
				if (emailId.equals(user.getEmailId())) {
					return 1;
				}
			}
			String sql = "insert into users(name,email,userName,password,autoPassword,contact) values(?,?,?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, user.getName());
			ps.setString(2, user.getEmailId());
			ps.setString(3, user.getUserName());
			ps.setString(4, user.getPassword());
			ps.setString(5, PasswordGenerator.generateRandomPassword());
			ps.setString(6, user.getContactNumber());
			int i1 = ps.executeUpdate();
			if (i1 > 1) {
				System.out.println("inserted.....");
			} else {
				System.out.println("no inserted.......");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 2;
	}

	public int loginUser(User user) {
		try {
			String s3 = "select * from users where userName=? and password=?";
			ps = con.prepareStatement(s3);
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getPassword());
			rs = ps.executeQuery();
			System.out.println("**************");
			while (rs.next()) {
				String userName = rs.getString("userName");
				String password = rs.getString("password");
				System.out.println("***y66788$$$$$$$$");
				if (userName.equals(user.getUserName()) && password.equals(user.getPassword())) {
					return 1;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 2;
	}

	public int addQuestion(Question ques) {
		try {
			String sql = "insert into question(question,subject,branch,semester,difficulty,module) values(?,?,?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, ques.getQuestion());
			ps.setString(2, ques.getSubject());
			ps.setString(3, ques.getBranch());
			ps.setString(4, ques.getSemester());
			ps.setString(5, ques.getDoq());
			ps.setString(6, ques.getModule());
			int i1 = ps.executeUpdate();
			if (i1 > 1) {
				System.out.println("inserted.....");
			} else {
				System.out.println("no inserted.......");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 1;
	}

	public List<Question> createPaperEasy(Question ques) {
		List<Question> al = new ArrayList<Question>();
		try {
			String s3 = "select * from questions where institute=? and branch=? and semester=? and subject=? and module=? and doq='Easy'";
			ps = con.prepareStatement(s3);
//			ps.setString(1, ques.getInstitute());
//			ps.setString(2, ques.getBranch());
//			ps.setString(3, ques.getSemester());
//			ps.setString(4, ques.getSubject());
//			ps.setString(5, ques.getModule());
			rs = ps.executeQuery();
			while (rs.next()) {
				ques = new Question();
//				ques.setInstitute(rs.getString("institute"));
//				ques.setQuestion(rs.getString("questions"));
//				ques.setDoq(rs.getString("doq"));
//				ques.setModule(rs.getString("module"));
//				ques.setSubject(rs.getString("subject"));
//				ques.setSemester(rs.getString("semester"));
//				ques.setBranch(rs.getString("branch"));
//				al.add(ques);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return al;
	}

	
	public List<Question> showQuestion(Question ques) {
		System.out.println("Data Retriving ......");
		List<Question> al = new ArrayList<Question>();
		try {
			String s3 = "select * from question where branch=? and semester=? and subject=?";
			ps = con.prepareStatement(s3);
			ps.setString(1, ques.getBranch());
			ps.setString(2, ques.getSemester());
			ps.setString(3, ques.getSubject());
			rs = ps.executeQuery();
			while (rs.next()) {
				ques = new Question();
				ques.setQuestion(rs.getString("question"));
				ques.setDoq(rs.getString("DIFFICULTY"));
				ques.setModule(rs.getString("module"));
				ques.setSubject(rs.getString("subject"));
				ques.setSemester(rs.getString("semester"));
				ques.setBranch(rs.getString("branch"));
				al.add(ques);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return al;
	}

	
	public List<Question> createPaperMedium(Question ques) {
		List<Question> al = new ArrayList<Question>();
		try {
			String s3 = "select * from questions where institute=? and branch=? and semester=? and subject=? and module=? and doq='Medium'";
			ps = con.prepareStatement(s3);
//			ps.setString(1, ques.getInstitute());
//			ps.setString(2, ques.getBranch());
//			ps.setString(3, ques.getSemester());
//			ps.setString(4, ques.getSubject());
//			ps.setString(5, ques.getModule());
			rs = ps.executeQuery();
			while (rs.next()) {
				ques = new Question();
//				ques.setInstitute(rs.getString("institute"));
//				ques.setQuestion(rs.getString("questions"));
//				ques.setDoq(rs.getString("doq"));
//				ques.setModule(rs.getString("module"));
//				ques.setSubject(rs.getString("subject"));
//				ques.setSemester(rs.getString("semester"));
//				ques.setBranch(rs.getString("branch"));
				al.add(ques);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return al;
	}

	
	public List<Question> createPaperHard(Question ques) {
		List<Question> al = new ArrayList<Question>();
		try {
			String s3 = "select * from questions where institute=? and branch=? and semester=? and subject=? and module=? and doq='Hard'";
			ps = con.prepareStatement(s3);
//			ps.setString(1, ques.getInstitute());
//			ps.setString(2, ques.getBranch());
//			ps.setString(3, ques.getSemester());
//			ps.setString(4, ques.getSubject());
//			ps.setString(5, ques.getModule());
			rs = ps.executeQuery();
			while (rs.next()) {
				ques = new Question();
//				ques.setInstitute(rs.getString("institute"));
//				ques.setQuestion(rs.getString("questions"));
//				ques.setDoq(rs.getString("doq"));
//				ques.setModule(rs.getString("module"));
//				ques.setSubject(rs.getString("subject"));
//				ques.setSemester(rs.getString("semester"));
//				ques.setBranch(rs.getString("branch"));
				al.add(ques);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return al;
	}

	
	public int deleteQuestion(String question) {
		try {
			Connection connection = DBConnection.getMySQLConnection();
			String qry = "delete from question where question = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(qry);
			preparedStatement.setString(1, question);
			int status = preparedStatement.executeUpdate();
			if (status == 1) {
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}

	public List<Question> getQuestionByDifficulty(QuestionDetails details) {
		List<Question> list = new ArrayList<Question>();
		try {
			Connection connection = DBConnection.getMySQLConnection();
			String qry = "select * from question where difficulty = ? AND subject = ? AND branch = ? AND semester = ? AND module = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(qry);
			preparedStatement.setString(1, details.getDifficulty());
			preparedStatement.setString(2, details.getSubject());
			preparedStatement.setString(3, details.getBranch());
			preparedStatement.setString(4, details.getSemester());
			preparedStatement.setString(5, details.getModule());
			ResultSet resultSet = preparedStatement.executeQuery();
			Question question = null;
			while(resultSet.next()) {
				question = new Question();
				question.setQuestion(resultSet.getString(1));
				question.setMarks(resultSet.getString(2));
				question.setDoq(resultSet.getString(6));
				question.setSubject(resultSet.getString(3));
				list.add(question);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<Question> getExamQuestion(QuestionDetails details) {
		List<Question> list = new ArrayList<Question>();
		try {
			System.out.println("Question is Retiving from DB");
			Connection connection = DBConnection.getMySQLConnection();
			String qry = "select * from question where subject = ? AND branch = ? AND semester = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(qry);
			preparedStatement.setString(1, details.getSubject());
			preparedStatement.setString(2, details.getBranch());
			preparedStatement.setString(3, details.getSemester());
			ResultSet resultSet = preparedStatement.executeQuery();
			Question question = null;
			while(resultSet.next()) {
				question = new Question();
				question.setQuestion(resultSet.getString(1));
				question.setMarks(resultSet.getString(2));
				question.setDoq(resultSet.getString(3));
				list.add(question);
			}
			System.out.println("------->"+list);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public int saveContact(ContactUs contact) {
		try {
			String sql = "insert into contactus(name,email,phone,message) values(?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, contact.getName());
			ps.setString(2, contact.getEmail());
			ps.setString(3, contact.getPhone());
			ps.setString(4, contact.getMessage());

			int i1 = ps.executeUpdate();
			if (i1 >= 1) {
				System.out.println("contact saved...");
			} else {
				System.out.println("contact not saved...");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 1;
	}
	
}